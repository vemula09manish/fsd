CARECOMPASS - BEDFINDER BLITZ (HTML FRONTEND)

HOW TO RUN IN VS CODE
1. Extract carecompass_html.zip.
2. Open the extracted folder in Visual Studio Code.
3. Open index.html.
4. Right-click index.html and choose "Open with Live Server" (recommended).
   If Live Server is not installed, install the VS Code extension named "Live Server".
   You can also double-click index.html to open it in a browser.

FEATURES
- Hospital directory with sample 15 hospitals.
- General, ICU, Ventilator and Oxygen bed counters.
- Specialty and emergency-facility filters.
- GPS location and Haversine distance sorting.
- Call hospital and India emergency number 112 links.
- Google Maps driving directions.
- Leaflet / OpenStreetMap hospital map.
- Admin bed update console; demo password: admin123.
- Status badges: Normal, Busy, ER Full - Divert.
- Bed updates saved in browser localStorage.

IMPORTANT
This is a frontend-only academic demo. Hospital data is fictional/sample data and is not live or verified. The admin password is client-side demonstration protection, not production security. Leaflet map tiles require internet access. Real deployment needs a secure backend, authenticated hospital staff, verified hospital data and real-time data synchronization.
